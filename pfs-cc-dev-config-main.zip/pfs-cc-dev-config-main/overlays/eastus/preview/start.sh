#!/bin/bash

# prerequisites before you run this script

# 1. you need to customize the variables in the terraform.tfvars file
# 2. you need customize below two api key/secret environment variables

# export TF_VAR_confluent_cloud_api_key="<cloud_api_key>"
# export TF_VAR_confluent_cloud_api_secret="<cloud_api_secret>"

# the whole deployment may cost more than ten minutes, so just wait

timer_start=`date "+%Y-%m-%d %H:%M:%S"`
start_time_s=`date +%s`
echo "begin to deploy private link confluent cloud cluster： $timer_start"

terraform init
terraform fmt
terraform validate
terraform plan
terraform apply -auto-approve

timer_end=`date "+%Y-%m-%d %H:%M:%S"`
end_time_s=`date +%s`
echo "end to deploy private link confluent cloud cluster： $timer_end"
cost_time=$[ $end_time_s - $start_time_s ]
echo "$timer_start ---> $timer_end" "Total:$cost_time seconds"



