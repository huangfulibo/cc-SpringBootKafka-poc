#!/bin/bash

# 1. install docker && git & jdk
sudo -i
zypper --non-interactive install java-11-openjdk
zypper --non-interactive install git

cd /home/badi/
# 2. download confluent
sudo curl -O http://packages.confluent.io/archive/7.2/confluent-7.2.2.tar.gz

# 3. extract
tar -xzvf confluent-7.2.2.tar.gz
echo y | rm confluent-7.2.2.tar.gz

